/**
 * sources.js — Supported Source Registry
 * ----------------------------------------
 * Central registry of supported marketplaces. Each entry declares HOW the
 * aggregator is permitted to gather data from that source. We deliberately
 * encode a policy per source so the aggregation layer can NEVER touch a site
 * in a way that violates its terms.
 *
 * access modes:
 *   - "public_api"   : site exposes an official/allowed public API.
 *   - "public_page"  : only publicly available listing pages, light-touch.
 *   - "affiliate"    : data available via an allowed affiliate/partner feed.
 *
 * `enabled: false` sources are known marketplaces we do NOT currently pull
 * from (e.g. no allowed programmatic access). They are listed for
 * transparency but never queried.
 *
 * NOTE: This reference implementation ships with a deterministic offline
 * data provider (see providers/sampleProvider.js). Real network adapters can
 * be dropped in per-source without changing the rest of the pipeline, as long
 * as they honor the declared `access` policy and `robotsRespected` flag.
 */

export const SOURCES = [
  {
    id: 'keyvault',
    name: 'KeyVault',
    domain: 'keyvault.example',
    icon: '🔑',
    color: '#6366f1',
    access: 'public_api',
    sells: ['key'],
    robotsRespected: true,
    rateLimitMs: 800,
    enabled: true,
    baseReputation: 0.86,
  },
  {
    id: 'gamersden',
    name: 'GamersDen',
    domain: 'gamersden.example',
    icon: '🎮',
    color: '#10b981',
    access: 'public_api',
    sells: ['account', 'key'],
    robotsRespected: true,
    rateLimitMs: 1000,
    enabled: true,
    baseReputation: 0.79,
  },
  {
    id: 'accountbazaar',
    name: 'AccountBazaar',
    domain: 'accountbazaar.example',
    icon: '🛡️',
    color: '#f59e0b',
    access: 'public_page',
    sells: ['account'],
    robotsRespected: true,
    rateLimitMs: 1500,
    enabled: true,
    baseReputation: 0.71,
  },
  {
    id: 'cdkeydepot',
    name: 'CDKeyDepot',
    domain: 'cdkeydepot.example',
    icon: '💿',
    color: '#ef4444',
    access: 'affiliate',
    sells: ['key'],
    robotsRespected: true,
    rateLimitMs: 600,
    enabled: true,
    baseReputation: 0.83,
  },
  {
    id: 'playmarket',
    name: 'PlayMarket',
    domain: 'playmarket.example',
    icon: '🕹️',
    color: '#8b5cf6',
    access: 'public_api',
    sells: ['account', 'key'],
    robotsRespected: true,
    rateLimitMs: 900,
    enabled: true,
    baseReputation: 0.88,
  },
  {
    id: 'questkeys',
    name: 'QuestKeys',
    domain: 'questkeys.example',
    icon: '⚔️',
    color: '#06b6d4',
    access: 'affiliate',
    sells: ['key'],
    robotsRespected: true,
    rateLimitMs: 700,
    enabled: true,
    baseReputation: 0.74,
  },
  {
    id: 'vaultaccounts',
    name: 'VaultAccounts',
    domain: 'vaultaccounts.example',
    icon: '🏰',
    color: '#ec4899',
    access: 'public_page',
    sells: ['account'],
    robotsRespected: true,
    rateLimitMs: 1400,
    enabled: true,
    baseReputation: 0.68,
  },
  {
    id: 'instantkeys',
    name: 'InstantKeys',
    domain: 'instantkeys.example',
    icon: '⚡',
    color: '#22c55e',
    access: 'public_api',
    sells: ['key'],
    robotsRespected: true,
    rateLimitMs: 500,
    enabled: true,
    baseReputation: 0.81,
  },
  {
    id: 'eliteaccounts',
    name: 'EliteAccounts',
    domain: 'eliteaccounts.example',
    icon: '👑',
    color: '#eab308',
    access: 'public_page',
    sells: ['account'],
    robotsRespected: true,
    rateLimitMs: 1200,
    enabled: true,
    baseReputation: 0.77,
  },
  {
    id: 'pixelkeys',
    name: 'PixelKeys',
    domain: 'pixelkeys.example',
    icon: '🟪',
    color: '#a855f7',
    access: 'affiliate',
    sells: ['account', 'key'],
    robotsRespected: true,
    rateLimitMs: 650,
    enabled: true,
    baseReputation: 0.72,
  },
];

/** Returns only sources we are allowed to and configured to query. */
export function activeSources(kind /* 'account' | 'key' | 'both' */) {
  return SOURCES.filter((s) => {
    if (!s.enabled || !s.robotsRespected) return false;
    if (kind === 'both') return true;
    return s.sells.includes(kind);
  });
}

export function sourceById(id) {
  return SOURCES.find((s) => s.id === id);
}
