/**
 * sampleProvider.js — Listing Provider (offline reference adapter)
 * ----------------------------------------------------------------
 * This module is the boundary between "the pipeline" and "the outside world".
 *
 * In a production deployment you would implement one adapter per source that
 * fetches from that source's allowed public API / public page and normalizes
 * the response into the common Listing shape below. The rest of the system
 * (ranking, caching, review analysis) does not care where the data came from.
 *
 * To keep this project fully runnable with no external dependencies or any
 * scraping of real third-party sites, this reference adapter synthesizes
 * realistic, DETERMINISTIC listings from a seed (game + source). Same query
 * always yields the same data, which also makes caching meaningful.
 *
 * Common Listing shape (normalized):
 * {
 *   id, sourceId, title, price, currency, url, kind ('account'|'key'),
 *   ratingValue (0-5), ratingCount, deliveryMinutes, reviews: [string],
 *   inStock
 * }
 */

// --- tiny seeded PRNG so output is deterministic per (game, source) -------
function hashString(str) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function mulberry32(seed) {
  return function () {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const ACCOUNT_QUALIFIERS = [
  'Level Maxed', 'Full Access', 'Veteran', 'Rare Skins', 'Ranked Ready',
  'Fresh Start', 'Loaded Inventory', 'Collector Edition', 'Prestige', 'Stacked',
];
const KEY_QUALIFIERS = [
  'Global Key', 'Standard Edition', 'Deluxe Edition', 'Ultimate Edition',
  'Steam Key', 'Region Free', 'Instant Delivery', 'GOTY Edition', 'Pre-Order',
];

const POSITIVE_REVIEWS = [
  'Instant delivery, worked perfectly.',
  'Smooth transaction and responsive seller.',
  'Exactly as described, would buy again.',
  'Key activated on the first try.',
  'Great communication throughout.',
  'Account login worked without issues.',
  'Fast, legit, and well priced.',
  'Trusted seller, no complaints.',
];
const MIXED_REVIEWS = [
  'Delivery took a little longer than expected.',
  'Worked but support was slow to reply.',
  'Fine overall, minor hiccup at checkout.',
  'Decent value, activation needed a retry.',
];
const NEGATIVE_REVIEWS = [
  'Had to wait hours for the key.',
  'Region restrictions were not clearly stated.',
  'Refund process was a bit tedious.',
];

/**
 * Generate normalized listings for a single source. Pure + deterministic.
 * @returns {Promise<Listing[]>}
 */
export async function fetchListings({ game, source, kind, want }) {
  // Simulate per-source latency so the pipeline timing feels real, but keep
  // it bounded. Real adapters would do actual network I/O here.
  const latency = 120 + (hashString(source.id + game) % 240);
  await new Promise((r) => setTimeout(r, latency));

  const rand = mulberry32(hashString(`${game}::${source.id}::${kind}`));
  const kinds =
    source.sells.length === 1
      ? source.sells
      : kind === 'both'
      ? source.sells
      : [kind];

  // Each source returns a handful of candidate listings; the pipeline pools
  // and re-ranks across all sources, then trims to the requested amount.
  const count = 3 + Math.floor(rand() * 4); // 3–6 per source
  const listings = [];

  // Anchor a base price per game so different sources cluster realistically.
  const gameAnchor = 8 + (hashString(game) % 52); // $8–$60 base

  for (let i = 0; i < count; i++) {
    const listingKind = kinds[Math.floor(rand() * kinds.length)];
    const qualifierPool =
      listingKind === 'account' ? ACCOUNT_QUALIFIERS : KEY_QUALIFIERS;
    const qualifier = qualifierPool[Math.floor(rand() * qualifierPool.length)];

    // Price: anchor +/- spread, accounts skew pricier than keys.
    const kindMultiplier = listingKind === 'account' ? 1.6 : 1.0;
    const spread = 0.55 + rand() * 0.95; // 0.55x – 1.5x
    const price = +(gameAnchor * kindMultiplier * spread).toFixed(2);

    // Rating influenced by source baseReputation + noise.
    const ratingValue = Math.max(
      2.6,
      Math.min(5, source.baseReputation * 5 + (rand() - 0.5) * 1.3)
    );
    const ratingCount = 12 + Math.floor(rand() * 2400);

    // Reviews: sample a mix weighted by rating.
    const reviews = [];
    const reviewCount = 2 + Math.floor(rand() * 3);
    for (let r = 0; r < reviewCount; r++) {
      const roll = rand();
      if (ratingValue >= 4.3 ? roll < 0.85 : roll < 0.55) {
        reviews.push(POSITIVE_REVIEWS[Math.floor(rand() * POSITIVE_REVIEWS.length)]);
      } else if (roll < 0.85) {
        reviews.push(MIXED_REVIEWS[Math.floor(rand() * MIXED_REVIEWS.length)]);
      } else {
        reviews.push(NEGATIVE_REVIEWS[Math.floor(rand() * NEGATIVE_REVIEWS.length)]);
      }
    }

    const deliveryMinutes =
      source.access === 'public_api' || source.access === 'affiliate'
        ? Math.floor(rand() * 12) // near-instant for API/affiliate feeds
        : 10 + Math.floor(rand() * 240); // manual fulfilment for page sources

    const titleGame = game
      .split(' ')
      .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
      .join(' ');

    listings.push({
      id: `${source.id}-${i}-${hashString(game + qualifier + i)}`,
      sourceId: source.id,
      title: `${titleGame} — ${qualifier}`,
      price,
      currency: 'USD',
      url: `https://${source.domain}/listing/${encodeURIComponent(
        titleGame.toLowerCase().replace(/\s+/g, '-')
      )}-${i}`,
      kind: listingKind,
      ratingValue: +ratingValue.toFixed(2),
      ratingCount,
      deliveryMinutes,
      reviews,
      inStock: rand() > 0.05,
    });
  }

  return listings.filter((l) => l.inStock);
}
