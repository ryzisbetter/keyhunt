# KeyHunt — Game Account & Key Price Aggregator (Demo)

A polished demo web app that compares game key/account listings, weighs seller
reputation from reviews, and ranks results by value.

> NOTE: The listings are realistic but **generated sample data** (not real live
> prices). This is a working demo / portfolio piece. Wiring in real sources is a
> separate, larger project.

## How to run it on your computer (Windows)

You need Node.js installed first — get the "LTS" version from https://nodejs.org

1. Unzip this folder (e.g. to your Desktop).
2. Open the `backend` folder in File Explorer.
3. Click the address bar at the top, type `powershell`, press Enter.
4. In the window that opens, run:

   ```
   npm install
   ```

   then:

   ```
   node server.js
   ```

5. You should see: `KeyHunt running → http://localhost:3000`
6. Open a browser and go to:  http://localhost:3000

To stop it: click the PowerShell window and press Ctrl + C.
To start it again later: reopen PowerShell in the `backend` folder and run
`node server.js` (you only need to do `npm install` once).

## Project structure

- `frontend/` — the website (HTML, CSS, JavaScript) the browser shows
- `backend/`  — the Node.js server that powers the search
  - `server.js` — the web server
  - `services/` — the aggregation pipeline (sources, provider, review analysis,
    caching, ranking)
